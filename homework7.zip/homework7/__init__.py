# 3. Соберите из созданных на уроке и в рамках домашнего задания функций пакет для работы с файлами.

__all__ = ['exersize1', 'exersize2', 'exersize3', 'exersize4', 'exersize5', 'exersize6', 'exersize7', 'task2']